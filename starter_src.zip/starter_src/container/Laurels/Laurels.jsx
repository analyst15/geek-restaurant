import React from 'react';

import './Laurels.css';

const Laurels = () => (
  <div>
    Laurels
  </div>
);

export default Laurels;
